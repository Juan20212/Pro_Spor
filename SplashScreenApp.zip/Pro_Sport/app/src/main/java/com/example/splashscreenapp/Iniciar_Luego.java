package com.example.splashscreenapp;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Iniciar_Luego extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iniciar_luego);
    }


    public void vista(View view) {
        Intent intent = new Intent(Iniciar_Luego.this, Detalleproducto.class);
        startActivity(intent);
    }

    public void vista2(View view) {
        Intent intent = new Intent(Iniciar_Luego.this, Detalleproducto2.class);
        startActivity(intent);
    }

    public void vista3(View view) {
        Intent intent = new Intent(Iniciar_Luego.this, Detalleproducto3.class);
        startActivity(intent);
    }

    public void vista4(View view) {
        Intent intent = new Intent(Iniciar_Luego.this, Detalleproducto4.class);
        startActivity(intent);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // MenuInflater menuInflater = getMenuInflater ();
        getMenuInflater().inflate(R.menu.menu, menu);
        //menuInflater.inflate ();

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.Perfil:
                Intent intentperfil = new Intent(Iniciar_Luego.this, Activity_Cuenta.class);
                startActivity(intentperfil);
                Toast.makeText(this, "Perfil", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.Salir:
                Intent intent = new Intent(Iniciar_Luego.this, Iniciar_Sesion.class);
                startActivity(intent);
                Toast.makeText(this, "Salir", Toast.LENGTH_SHORT).show();
                return true;

            default:
                return super.onOptionsItemSelected(item);

        }

    }

    public void onClick(View view) {
        Intent intent = new Intent(Iniciar_Luego.this, Activity_Cuenta.class);
        startActivity(intent);
    }

    public void Busqueda(View view) {
        Intent intent = new Intent(Iniciar_Luego.this,MainActivity_.class);
        startActivity(intent);
    }
}




