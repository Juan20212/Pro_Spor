package com.example.splashscreenapp;

import android.app.DownloadManager;
import android.content.Intent;
import android.os.Bundle;
import android.os.strictmode.CredentialProtectedWhileLockedViolation;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;


public class MainActivity extends AppCompatActivity {



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void inicar(View view) {
        Intent intent = new Intent(MainActivity.this, Iniciar_Luego.class);
        startActivity(intent);
    }

    public void iniciat_sesion(View view) {
        Intent intent = new Intent(MainActivity.this, Iniciar_Sesion.class);
        startActivity(intent);
    }

    public void Registarse(View view) {
        Intent intent = new Intent(MainActivity.this,Registrarse.class);
        startActivity(intent);
    }
}